
package mahasiswa;

import java.awt.image.BufferedImage;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import static mahasiswa.koneksi.buatkoneks;

/**
 *
 * @author User
 */
public class Absensi extends javax.swing.JFrame {
    DefaultTableModel TM = new DefaultTableModel();

    /**
     * Creates new form Absensi
     */
    public Absensi() {
        initComponents();
        tbDATA.setModel(TM);
        TM.addColumn("Nim");
        TM.addColumn("Nama");
        TM.addColumn("Jurusan");
        TM.addColumn("Prodi");
    
        try {
            List_All();
        } catch (SQLException ex) {
            Logger.getLogger(Absensi.class.getName()).log(Level.SEVERE, null, ex);
        }
        kosongkanform();
        loadphoto("");
    }
    private void loadphoto(String idx){
        String nopic = "src/img/1.jpg";
        String ph = "src/img/"+idx+".jpg";
        BufferedImage phototeman = loadIMG.loadImage(ph);
        if(phototeman == null){
            phototeman = loadIMG.loadImage(nopic);
        }
        ImageIcon iconphoto = new ImageIcon(phototeman);
        photo.setIcon(iconphoto);
    }
    
    private void List_All() throws SQLException{
        TM.getDataVector().removeAllElements();
        TM.fireTableDataChanged();
        
        Connection cnn = buatkoneks();
        if( !cnn.isClosed() ){
            
            String sql = "SELECT * FROM Absensi;";
            PreparedStatement PS = cnn.prepareStatement(sql);
            ResultSet rs = PS.executeQuery();
            while( rs.next() ){
                Object[] dta = new Object[4];
                dta[0] = rs.getInt("Nim");
                dta[1] = rs.getString("Nama");
                dta[2] = rs.getString("Jurusan");
                dta[3] = rs.getString("Prodi");
                TM.addRow(dta);
            }
        }
        
    }
    
    private void StoreData() throws SQLException{
        Connection cnn = buatkoneks();
        String NI = txNIM.getText();
        String NM = txNAMA.getText();
        String JU = txJURUSAN.getText();
        String PR = txPRODI.getText();
        if(!cnn.isClosed()){
            PreparedStatement PS = cnn.prepareStatement("INSERT INTO teman(Nim,Nama,Jurusan,Prodi) VALUES(?,?,?,?);");
            PS.setString(1, NI);
            PS.setString(2, NM);
            PS.setString(3, JU);
            PS.setString(4, PR);
            PS.executeUpdate();
        }
    }
    
    private void UpdateData() throws SQLException{
        Connection cnn=buatkoneks();
        if(!cnn.isClosed()){
            PreparedStatement PS = cnn.prepareStatement("UPDATE Absensi SET Nama=?, Jurusan=?, Prodi=? WHERE Nim=?");
            PS.setString(1, txNIM.getText() );
            PS.setString(2, txNAMA.getText() );
            PS.setString(3, txJURUSAN.getText() );
            PS.setString(4, txPRODI.getText() );           
            PS.executeUpdate();
            cnn.close();
        }
    }
    
    private void destroyData() throws SQLException{
        Connection cnn = buatkoneks();
        if(!cnn.isClosed()){
            PreparedStatement PS = cnn.prepareStatement("DELETE FROM teman WHERE Nim=?;");
            PS.setString(1, txNIM.getText() );
            PS.executeUpdate();
            cnn.close();
        }
    }
    private void kosongkanform(){
        txNIM.setText("");
        txNAMA.setText("");
        txJURUSAN.setText("");
        txPRODI.setText("");
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        JLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txNIM = new javax.swing.JTextField();
        txNAMA = new javax.swing.JTextField();
        txPRODI = new javax.swing.JTextField();
        txJURUSAN = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbDATA = new javax.swing.JTable();
        btnBARU = new javax.swing.JButton();
        btnUBAH = new javax.swing.JButton();
        btnHAPUS = new javax.swing.JButton();
        btnTUTUP = new javax.swing.JButton();
        photo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 153, 51));
        jLabel1.setText("Absensi Mahasiswa Instiki");

        JLabel1.setText("Nim :");

        jLabel2.setText("Nama :");

        jLabel3.setText("Jurusan : ");

        jLabel4.setText("Prodi : ");

        txPRODI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txPRODIActionPerformed(evt);
            }
        });

        tbDATA.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Nim", "Nama", "Jurusan", "Prodi"
            }
        ));
        tbDATA.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                tbDATAAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane1.setViewportView(tbDATA);

        btnBARU.setText("BARU");
        btnBARU.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBARUActionPerformed(evt);
            }
        });

        btnUBAH.setText("UBAH");
        btnUBAH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUBAHActionPerformed(evt);
            }
        });

        btnHAPUS.setText("HAPUS");
        btnHAPUS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHAPUSActionPerformed(evt);
            }
        });

        btnTUTUP.setText("TUTUP");
        btnTUTUP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTUTUPActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(120, 120, 120)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(JLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4))
                        .addGap(21, 21, 21)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txNAMA, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 209, Short.MAX_VALUE)
                            .addComponent(txJURUSAN, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txPRODI, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txNIM))
                        .addGap(41, 41, 41)
                        .addComponent(photo, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 372, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnBARU)
                                .addGap(33, 33, 33)
                                .addComponent(btnUBAH)
                                .addGap(27, 27, 27)
                                .addComponent(btnHAPUS)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnTUTUP)))))
                .addContainerGap(27, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(JLabel1)
                            .addComponent(txNIM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txNAMA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txJURUSAN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(photo, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txPRODI, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(53, 53, 53)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBARU, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnUBAH, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnHAPUS, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTUTUP, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(101, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txPRODIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txPRODIActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txPRODIActionPerformed

    private void btnUBAHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUBAHActionPerformed
         try {
            UpdateData();
            List_All();
            
            JOptionPane.showMessageDialog(this, "Data telah diupdate");
            
        } catch (SQLException ex) {
            Logger.getLogger(Absensi.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnUBAHActionPerformed

    private void btnTUTUPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTUTUPActionPerformed
        if(btnTUTUP.getText().equals("TutupForm")){
            dispose();
        }else{
            btnTUTUP.setText("TutupForm");
            btnBARU.setText("Baru");
        }
    }//GEN-LAST:event_btnTUTUPActionPerformed

    private void btnHAPUSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHAPUSActionPerformed
        int jwb = JOptionPane.showOptionDialog(
                this, 
                "Yakin akan menghapus data "+txNAMA.getText()+"?", 
                "Hapus Data", 
                JOptionPane.YES_NO_OPTION, 
                JOptionPane.WARNING_MESSAGE, 
                null, 
                null, 
                null);
                if(jwb == JOptionPane.YES_OPTION ){
            try {
                destroyData();
                List_All();
            } catch (SQLException ex) {
                Logger.getLogger(Absensi.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_btnHAPUSActionPerformed

    private void tbDATAAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_tbDATAAncestorAdded
        txNIM.setText( tbDATA.getValueAt( tbDATA.getSelectedRow(),0 ).toString() );
        txNAMA.setText( tbDATA.getValueAt( tbDATA.getSelectedRow(), 1).toString() );
        txJURUSAN.setText( tbDATA.getValueAt(tbDATA.getSelectedRow(), 2).toString() );
        txPRODI.setText( tbDATA.getValueAt(tbDATA.getSelectedRow(), 3).toString() );
        loadphoto(txNIM.getText());
    }//GEN-LAST:event_tbDATAAncestorAdded

    private void btnBARUActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBARUActionPerformed
        if(btnBARU.getText().equals("Baru")){
            btnBARU.setText("Simpan");
            btnTUTUP.setText("Batal");
            kosongkanform();
            tbDATA.setEnabled(false);
        }else{
            btnBARU.setText("Baru");
            btnTUTUP.setText("TutupForm");
            tbDATA.setEnabled(true);
            try {
                StoreData();
                List_All();
            } catch (SQLException ex) {
                Logger.getLogger(Absensi.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_btnBARUActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Absensi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Absensi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Absensi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Absensi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Absensi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel JLabel1;
    private javax.swing.JButton btnBARU;
    private javax.swing.JButton btnHAPUS;
    private javax.swing.JButton btnTUTUP;
    private javax.swing.JButton btnUBAH;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel photo;
    private javax.swing.JTable tbDATA;
    private javax.swing.JTextField txJURUSAN;
    private javax.swing.JTextField txNAMA;
    private javax.swing.JTextField txNIM;
    private javax.swing.JTextField txPRODI;
    // End of variables declaration//GEN-END:variables
}
