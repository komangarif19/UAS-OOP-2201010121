
package mahasiswa;

/**
 *
 * @author User
 */
public class Mahasiswa {

    
    public static void main(String[] args) {
        Absensi ab = new Absensi();
        ab.setResizable(false);
        ab.setAlwaysOnTop(true);
        ab.setVisible(true);
    }
    
}
